/*
 * Command.cpp
 *
 *  Created on: 11 Dec 2018
 *      Author: Entvex
 */

#include "Command.h"

Command::Command() {
	// TODO Auto-generated constructor stub

}

Command::~Command() {
	// TODO Auto-generated destructor stub
}

